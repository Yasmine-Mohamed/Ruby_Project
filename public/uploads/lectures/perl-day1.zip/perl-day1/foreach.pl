#!/usr/bin/perl
 
@list = (2, 20, 30, 40, 50);

# foreach loop execution
foreach $a (@list){
    print "value of a: $a\n";
}
