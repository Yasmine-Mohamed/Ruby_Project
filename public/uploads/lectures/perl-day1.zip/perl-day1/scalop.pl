#!/usr/bin/perl

$str = "hello" . "world";       # Concatenates strings.
$num = 5 + 10;                  # adds two numbers.
$mul = 4 * 5;                   # multiplies two numbers.
$mix = $str . $num;             # concatenates string and number.
$str= $str x3 ;
print "str = $str\n";
print "num = $num\n";
print "mix = $mix\n";
