#!/usr/bin/perl

#$data=<STDIN>;
#chomp $data ;
#print "data = $data \n " ;
print " first element = $ARGV[0] \n ";
$count=@ARGV ;
print "number of sent param = $count \n";
print " the program name is $0 \n";
my $x = 10;
my $y = $x + 1;

print "Using a number $x + 1 = $y.\n";

$x = "10";
$y = $x + 1;

print "Using a string $x + 1 = $y.\n";

$x = "ten";
$y = $x + 1;

print "Using an English word, $x + 1 = $y.\n";

$x = "2ten";
$y = $x + 1;

print "Using a funny string, $x + 1 = $y.\n";
