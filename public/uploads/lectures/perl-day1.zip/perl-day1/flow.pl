#!/usr/bin/perl
 
$a = 30;
# check the boolean condition using if statement
if( $a  ==  20 ){
    # if condition is true then print the following
    printf "a has a value which is 20------\n";
}elsif( $a ==  30 ){
    # if condition is true then print the following
    printf "a has a value which is 30,,,,,,,,\n";
}else{
    # if none of the above conditions is true
    printf "a has a value which is $a\n";
}
=begin
$a = 100;
# check the boolean condition using unless statement
unless( $a == 20 ){
    # if condition is false then print the following
    printf "given condition is false\n";
}else{ 
    # if condition is true then print the following
    printf "given condition is true\n";
}
print "value of a is : $a\n";

$a = "";
# check the boolean condition using unless statement
unless( $a ){
    # if condition is false then print the following
    printf "a has a false value\n";
}else{
   # if condition is true then print the following
    printf "a has a true value\n";
}
print "value of a is : $a\n";

 
$name = "Ali";
$age = 10;

$status = ($age > 60 )? "A senior citizen" : "Not a senior citizen";

print "$name is  - $status\n";
=end
