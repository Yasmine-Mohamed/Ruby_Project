#!/usr/bin/python2.7 -tt

class Pet:
    'Common class for all kinds of pets'
    pet_count = 0
    
    def __init__(self , name, number_of_legs):
        print "Getting a new pet"
        self.name = name
        self.number_of_legs = number_of_legs
        Pet.pet_count +=1
    
    def show_data(self):
        print self.name
        print "This pet has %d legs" % self.number_of_legs
      
    def __del__(self):
        print "deleting ",self.name 
        
    @staticmethod
    def display_pet_count():
        print "Total # of Pets= " + str(Pet.pet_count)

class Dog(Pet):
    fur_color = None
    def __init__(self,name,number_of_legs,fur_color):
        print "Getting a new dog"
        
        #super(Dog,self).__init__(name,number_of_legs)
        Pet.__init__(self,name,number_of_legs)
        self.fur_color = fur_color
    def bark(self):
        print "woof woof"
    def show_data(self):
        print self.name
        print "This dog naturally has %d legs" % self.number_of_legs  
              
def main():
    my_dog = Pet("Roy",4)
    my_dog.show_data()
    
    my_fish = Pet("Nemo",0)
    my_fish.show_data()
    
    Pet.display_pet_count()
    
    print Pet.pet_count
    
    my_fish.color = "gray"
    
    print my_fish.color
    
    #del my_fish.color
    
    #print my_fish.color
    print delattr(my_fish,"color")
    print hasattr(my_fish,"name")
    print getattr(my_fish,"number_of_legs")
    setattr(my_fish,"name","bibo")          #return None
    print getattr(my_fish,"name")
    
    print Pet.__doc__
    print Pet.__bases__
    print Pet.__name__
    
    
    new_dog = Dog("kev",4,"brown")
    print "####"
    new_dog.show_data()
    #del my_fish
    
if __name__ == '__main__':
    main()
    
